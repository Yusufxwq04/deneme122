# tutorial-bot
Discord.js v12 Basic Bot with Basic Bot Commands

YouTube: https://www.youtube.com/channel/UC1zfP7GYvB2LD-49TQcYInQ?view_as=subscriber
Discord: https://www.discord.gg/3HCefjF
Oblivion Bot Invite: https://bradybots.com/


YouTube Episode 1: 
- Info command
- Whois command


YouTube Episode 2: 
- Clear command

YouTube Episode 3: 
(COMPLETE MAKEOVER)
- Command Handler
- Event Handler 
- Message Event 
- Ready Event
- Info Command 
- Clear Command
