This is to fix the Scandir error.
- Brady 
